import urllib.request as urllib2
from bs4 import BeautifulSoup
import csv
import sys
import os
import requests
import pandas as pd
import numpy as np
from tabulate import tabulate
#page="http://localhost/sandbox/random.php"
operation=1
while operation:
	print("-------------------------------------------------------\n")
	print("\t\t\tWELCOME to WebScraper Tool ..\n\n\t\tDeveloped by @Conrad\n")
	print("-------------------------------------------------------\n")
	print("Choose Option:\n A)Enter Scraper\n B)Quit")
	out=input("Enter Choice:\t")
	if out.upper()=="A":
		print("Please Type The full url path of the website You want To Scrape")
		website=input("Url:\t")
		if website:
			soup = BeautifulSoup(urllib2.urlopen(website).read(),"lxml")
			print("Website: ",website,"\n")
			print("\nInput the Class Name of the Table\n")
			class_name=input()
			table=soup("table",{"class":class_name})[0].find_all('tr')
			
			res = requests.get(website)
			soup2 = BeautifulSoup(res.content,'lxml')
			table2 = soup2.find('table',{"class":class_name})
			df = pd.read_html(str(table2))
			print( tabulate(df[0], headers='keys', tablefmt='psql') )	
			print("\n Do You Want To Export The Table To Excel Format\nY.(yes) N.(no)\n")
			choice=input("\nEnter Choice:\t")
			if choice.upper()=='Y':
				
				print("Do you wish to Create a New csv file ?? \t Y(yes) N(no) ")
				take=input("Enter choice:\t")
				if take.upper()=='Y':
					print("Type File Name:\t")
					file_name=input()
					file_name+='.csv'
					file2=open(file_name,'a',newline='')
					writer_custom=csv.writer(file2)	
					for content in table:
						cell=content.findChildren(recursive=False)
						cell=[element.text.strip() for element in cell]
						writer_custom.writerow(cell)
					print(file_name," exported Successfully")	
				else:
					name=website.replace("http://","")
					name=name.replace("/","-")
					name=name.replace(".php",".csv")
					file=open(name,"a",newline='')
					writer=csv.writer(file)
					for stuff in table:
						cell=stuff.findChildren(recursive=False)
						cell=[element.text.strip() for element in cell]
						writer.writerow(cell)			
					print(name," exported Successfully")	
			else:
				print("------------------------\n")
				print("\tExiting Program...")
				print("------------------------\n")
				exit()
		else:	
			print("[Empty Url] please type in the Url of the Site")		
	elif out.upper()=='B':
		print("-------------------------------------------------------\n")
		print("	\t\t\tExiting WebScraper\n")
		print("-------------------------------------------------------\n")
		operation=0		
	

