This Tool Enables you to Scrape Data from Tables in a Webpage
-Easy to Use, I made it as user friendly as possible

Usage:
-type full path of the URL of the Webpage
-Type the correct Class name for the Table
and follow the prompts and The Content will be Displayed 
-option is available for view or Export

@Conrad 1st-10-2017